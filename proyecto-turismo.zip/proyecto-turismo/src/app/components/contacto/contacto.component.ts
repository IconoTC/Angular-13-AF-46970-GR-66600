import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-contacto',
  templateUrl: './contacto.component.html',
  styleUrls: ['./contacto.component.css']
})
export class ContactoComponent implements OnInit {

  contactoForm = new FormGroup({
    nombre: new FormControl('', Validators.required),  
    apellido: new FormControl('', Validators.required),
    email: new FormControl('', [Validators.required, Validators.email]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[0-9]{9}')]),
    asunto: new FormControl('', Validators.required),
    mensaje: new FormControl('', [Validators.required, Validators.minLength(10)])
  });

  constructor() { }

  ngOnInit(): void {
  }

}
