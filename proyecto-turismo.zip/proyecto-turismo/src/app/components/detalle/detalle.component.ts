import { MuseosService } from './../../services/museos.service';
import { ActivatedRoute } from '@angular/router';
import { Museo } from './../../models/museo';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.component.html',
  styleUrls: ['./detalle.component.css']
})
export class DetalleComponent implements OnInit {

  id: number = 0;
  museo: Museo | undefined;

  constructor(private ruta: ActivatedRoute, private museosService: MuseosService) { 
    this.id = ruta.snapshot.params['codigo'];
    this.museo = museosService.buscarMuseo(this.id);
  }

  ngOnInit(): void {
  }

}
