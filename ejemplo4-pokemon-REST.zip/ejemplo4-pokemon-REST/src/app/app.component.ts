import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  pokemons: any[] = [];
  siguientes: string = "";
  anteriores: string = "";
  nombre: string = "";
  pokemon: any;

  constructor(private pokemonService: PokemonService){

    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    // Me subscribo al Observable atenta al recibir los datos
    pokemonService.getAll().subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.siguientes = datos.next;
      this.anteriores = datos.previous;
    });

  }

  adelante(){
    this.pokemonService.emitirPeticion(this.siguientes).subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.siguientes = datos.next;
      this.anteriores = datos.previous;
    });
  }

  atras(){
    this.pokemonService.emitirPeticion(this.anteriores).subscribe( (datos) => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.siguientes = datos.next;
      this.anteriores = datos.previous;
    });
  }

  buscar(){
    this.pokemonService.buscarPokemon(this.nombre).subscribe( item => {
      console.log(item);
      this.pokemon = item;
    });
  }
}
