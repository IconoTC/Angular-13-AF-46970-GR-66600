import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './services/agenda.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];
  id: string = "";
  contacto: any;
  mostrar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),  
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])  
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().subscribe( datos => {
      //console.log(datos);
      this.amigos = [];
      datos.forEach(item => {
        console.log(item.payload.doc.id);
        console.log(item.payload.doc.data());
        this.amigos.push(item.payload.doc.data());
        this.amigos[this.amigos.length - 1].id = item.payload.doc.id
      })
    });
  }

  buscar(): void{
    this.agendaService.buscarAmigo(this.id).subscribe(item => {
      this.id = item.payload.id;
      this.contacto = item.payload.data();
    })
  }

  modificar(): void{
    this.amigoForm.setValue(this.contacto);
    this.mostrar = true;
  }

  guardar(){
    this.agendaService.modificar(this.id, this.amigoForm.value)
      .then(() => {
        alert("Contacto modificado");
        this.mostrar = false;
        this.amigoForm.reset();
        this.contacto = null;
        this.id = "";
      })
      .catch(error => {
        console.log(error);
      });
  }

  borrar(): void{
    this.agendaService.eliminar(this.id)
      .then(() => {
        alert("Contacto eliminado");
        this.contacto = null;
        this.id = "";
      })
      .catch(error => {
        console.log(error);
      });
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        alert("Contacto creado");
        this.amigoForm.reset();
      })
      .catch( (error) => {
        console.log(error)
      });
  }
}
