import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AgendaService } from './services/agenda.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  amigos: any[] = [];

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),  
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])  
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().subscribe( datos => {
      console.log(datos);
    });
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then( () => {
        alert("Contacto creado");
        this.amigoForm.reset();
      })
      .catch( (error) => {
        console.log(error)
      });
  }
}
