export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyD_tXajjvPaLSgMFpuX_VkCaJ5p_S2TbR8",
    authDomain: "angular-anabel-20-septiembre.firebaseapp.com",
    projectId: "angular-anabel-20-septiembre",
    storageBucket: "angular-anabel-20-septiembre.appspot.com",
    messagingSenderId: "354470774219",
    appId: "1:354470774219:web:1a6c781c640e48bf71a24e"
  }
};
